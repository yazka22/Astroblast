﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
namespace astroblast
{
    public partial class Form1 : Form
    {
        Int16 x=500, y=500, scorOZN = 0, scorAsteroid = 0;
        Point pozitieOZN, pozitieAsteroid;
        Random rnd = new Random();

        private void timerAsteroid_Tick(object sender, EventArgs e)
        {
            pozitieAsteroid.Y+= 5;
            if (pozitieAsteroid.Y >= 600)
            {
                pozitieAsteroid.Y = 1;
                pozitieAsteroid.X = rnd.Next(1, 1125);
                scorAsteroid++;
                this.Text = "Astroblast   OZN=" + scorOZN + "    Asteroid=" + scorAsteroid;
             }

            if(pictureBoxAsteroid.Bounds.IntersectsWith(pictureBoxUFO.Bounds))
            {
                pozitieAsteroid.Y = 1;
                pozitieAsteroid.X = rnd.Next(1, 1125);
                scorOZN++;
                this.Text = "Astroblast   OZN=" + scorOZN + "    Asteroid=" + scorAsteroid;
            }
            pictureBoxAsteroid.Invalidate();
            pictureBoxAsteroid.Location = pozitieAsteroid;
        }

        private void pictureBoxAsteroid_Click(object sender, EventArgs e)
        {

        }

        public Form1()
        {
            InitializeComponent();
            pozitieOZN.Y = 450;
            pozitieAsteroid.X = rnd.Next(1, 1125);
            DoubleBuffered = true;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Left) x -= 10;
            if (x <= 1) x = 1;
            if (e.KeyData == Keys.Right) x += 10;
            if (x >= 1035) x = 1035;
            pozitieOZN.X = x;
            pictureBoxUFO.Invalidate();
            pictureBoxUFO.Location = pozitieOZN;
        }
    }
}
