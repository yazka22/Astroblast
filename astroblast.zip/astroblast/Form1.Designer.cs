﻿
namespace astroblast
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBoxUFO = new System.Windows.Forms.PictureBox();
            this.pictureBoxAsteroid = new System.Windows.Forms.PictureBox();
            this.timerAsteroid = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUFO)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAsteroid)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxUFO
            // 
            this.pictureBoxUFO.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxUFO.BackgroundImage = global::astroblast.Properties.Resources.ufo;
            this.pictureBoxUFO.Location = new System.Drawing.Point(553, 557);
            this.pictureBoxUFO.Name = "pictureBoxUFO";
            this.pictureBoxUFO.Size = new System.Drawing.Size(203, 129);
            this.pictureBoxUFO.TabIndex = 0;
            this.pictureBoxUFO.TabStop = false;
            // 
            // pictureBoxAsteroid
            // 
            this.pictureBoxAsteroid.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxAsteroid.BackgroundImage = global::astroblast.Properties.Resources.firee;
            this.pictureBoxAsteroid.Location = new System.Drawing.Point(550, 12);
            this.pictureBoxAsteroid.Name = "pictureBoxAsteroid";
            this.pictureBoxAsteroid.Size = new System.Drawing.Size(108, 95);
            this.pictureBoxAsteroid.TabIndex = 1;
            this.pictureBoxAsteroid.TabStop = false;
            // 
            // timerAsteroid
            // 
            this.timerAsteroid.Enabled = true;
            this.timerAsteroid.Interval = 20;
            this.timerAsteroid.Tick += new System.EventHandler(this.timerAsteroid_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::astroblast.Properties.Resources.planet1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1135, 702);
            this.Controls.Add(this.pictureBoxAsteroid);
            this.Controls.Add(this.pictureBoxUFO);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Astroblast";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUFO)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAsteroid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxUFO;
        private System.Windows.Forms.PictureBox pictureBoxAsteroid;
        private System.Windows.Forms.Timer timerAsteroid;
    }
}

